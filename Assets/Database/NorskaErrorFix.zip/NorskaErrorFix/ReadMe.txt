Take the SpreadsheetContainerEditor.cs in this folder, and use it to overwrite the file in

Library\PackageCache\com.norska-lib.spreadsheets@bf43763b16\Editor\

